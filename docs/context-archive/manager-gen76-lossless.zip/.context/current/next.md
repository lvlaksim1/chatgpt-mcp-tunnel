## Входящее предложение Android-исследования для MCP Tunnel — поколение 76 (31.10.2026, 22:00 МСК)
Статус: PROPOSED, не активная задача и не разрешение на установку. По прямой просьбе владельца передано предложение: P0 пассивная диагностика сетевых метаданных WebView2 без секретов; P1 автомат состояний сообщения и запрет повторной отправки; P2 более надёжное озвучивание завершённых фрагментов; P3 обработка VPN-разрывов без дублей. Полный материал: .context/proposals/2026-10-31-android-research-tunnel.md. Менеджер должен самостоятельно оценить и явно принять/отклонить, не записывать как active без решения. Не считать мобильные имена JS доказательством HTTP-контракта Windows WebView2.

---

## GEN 74 — следующие задачи (31.10.2026 21:27 МСК)
1. Интегрировать клиентский Free Xray supervisor и трёхчасовой refresh в официальный установщик ChatGPT MCP Tunnel с учётом роли client, сохранить правило MKATUSHONOK: только Free для ChatGPT WebView2, без Happ; не менять серверный MCP tunnel-client DOMKAT. 2. Документировать восстановление клиентского VPN после чистой установки и безопасную повторную авторизацию без переноса приватных файлов в GitHub. 3. Проверить перезапуск MKATUSHONOK/автовосстановление и обновления публичных VLESS-профилей на длительном интервале, включая отсутствие прямого fallback. 4. Сохранить локальную резервную копию прежнего браузерного профиля; удаление только по отдельному указанию владельца. 5. Публиковать лишь не содержащие секретов исходники и документацию; GitHub — хранилище версий, сборка локальная, без prerelease.

---

## Operational next after stable v0.2.65 (31.10.2026 20:24 MSK)
1. Keep schedule refreshing free profiles every 3 hours and watch first 22:28 MSK cycle. 2. Maintain original authorized WebView2 and local rollback backup. 3. Future releases use local build + tests + DOMKAT install first, safe non-force merge into main, stable GitHub release with full/update installer; never prereleases.

---

## Next after v0.2.65 — generation 72 (31.10.2026 20:18 MSK)
1. Verify Git staging excludes keys/DPAPI/auth backups and binary outputs. 2. Publish accepted v0.2.65 source and stable release to GitHub without prerelease, only after local installation and SHA256 test. 3. Continue 3-hour automated node updates, optional scheduled monitoring; maintain Happ rollback. 4. Preserve one authorized WebView2 profile and one official DOMKAT tunnel-client.

---

## Next — generation 71 (31.10.2026 19:40 MSK)
1. Preserve v0.2.64 Happ default, one shared signed-in ChatGPT UDF; do not create/copy any second browser profile. 2. Monitor upcoming scheduled free refresh for stability and collect bridge failback notice/health data. 3. Add user-facing status notification for automatic Happ fallback if useful; maintain single MCP server on DOMKAT and remote Router Lite clients. 4. Local-first release workflow, no prerelease/GitHub Actions; publish to GitHub only when directed/accepted.

---

## VPN next — gen 70 (31.10.2026 18:58 MSK)
1. Implement coherent GUI and server route state machine so external failback reinitializes WebView2 and updates UI indication correctly. 2. Fail-closed/alert and automatic managed switch Happ upon repeated failed Free probe, no OS direct route. 3. Reload owned Xray process when selected DPAPI profile changes, with preflight and rollback, avoid killing foreign processes. 4. If owner signs in separately to Free browser profile, test authenticated chat without leaking tokens. 5. Preserve working v0.2.63 and user auth, no second MCP tunnel.

---

## Next — generation 69 (31.10.2026 18:10 MSK)
1. Confirm GUI Happ/Free switching of both browser and official server MCP without PID replacement, owner-authenticated Free E2E only after explicit acceptance of public-exit trust. 2. Implement health monitored safe fallback to Happ with visible status and dynamically reload selected free node on scheduler refresh. 3. Preserve DOMKAT single tunnel and Router Lite clients; no per-client VPN or tunnel-client. 4. Archive local source to GitHub when acceptance complete; no GitHub Actions.

---

## Next — generation 68 (31.10.2026 17:08 MSK)
1. Confirm visible top-bar VPN: Happ dropdown and tray menu in installed v0.2.62. 2. Manually opt in to Free, validate isolated login and real chat/TTS on the public exit, then switch back to Happ and verify original MCP PIDs stay alive. 3. Investigate and implement official tunnel-client's HTTP/QUIC transport routing without additional MCP tunnel. 4. Hot-swap active free Xray upon scheduler updates after full acceptance, with fail-closed and rollback. 5. Preserve previous local changes and installed v0.2.62; do not run --shutdown.

---

## Next — generation 67 (31.10.2026 16:36 MSK)
1. Preserve current three-hour FreeReality refresh task and its last-good encrypted profile. 2. Add UI source listing and manual/automatic free-profile selection, with informed consent before routing private ChatGPT traffic to public unknown-provider nodes. 3. Validate Xray child restart/switchover and protection against transient failures, real WebView2 + official MCP transport E2E and secure rollback. 4. Keep Windows 10, single tunnel, Happ backup, and all existing local uncommitted changes.

---

## VPN next steps, generation 65 (31.10.2026 14:33 MSK)
1. Offer user tested public free link as ephemeral trial, not trusted production default. 2. If user authorizes experimental use, add explicit selection and fail-closed proxy with secure profile storage; ensure no private ChatGPT data silently routes through public node. 3. Verify durable trusted VPS or approved provider option for full independence from Happ. 4. Continue verifying process isolation and MCP transport, preserve existing running GUI v0.2.61.

---

## LamaVPN next steps — generation 64 (31.10.2026 14:12 MSK)
1. Obtain standard provider-issued vless:// TCP/REALITY Germany profile or compatible standard subscription, without posting tokens to chat/repository. 2. Import via scripts/Vpn/Import-VlessReality.ps1 from private local file. 3. Test secure connection using Start-ProtectedXrayProfile.ps1 with Happ still available and Xray bypass route verified by actual remote IP/routing diagnostics. 4. Validate logged-in WebView2 and separate MCP client, then add GUI profile management and safe rollback. 5. Keep existing v0.2.61 working, do not restart MCP or disable Happ.

---

## VPN next actions — поколение 63 (31.10.2026, 13:30 MSK)
1. Find or prepare trusted remote server supporting VLESS/REALITY and secure configuration/DPAPI secrets. 2. Verify actual ChatGPT WebView2 logged-in session through independent endpoint with Happ still running but not on the path. 3. Trace real tunnel-client/control-plane traffic, including optional QUIC, via embedded engine. 4. Add GUI profile selection/health and safe rollback; only after E2E prepare official release. 5. Keep existing voice v0.2.61 accepted, microphone STT deferred.

---

## Следующие шаги: поколение 62, 31.10.2026, 12:32 MSK
1. Не повторять диагностику наличия микрофона до его физического подключения. 2. При следующей регрессионной приёмке проверить 2/2 и 10/10 последовательных озвученных ответов, отсутствие дублей и поведение при смене вкладок. 3. После появления микрофона — испытать PTT, непрерывный режим и распознавание. 4. Текущая версия v0.2.61 уже принята по колонкам; не перезапускать работающий MCP-транспорт без задачи.

---

## АКТУАЛЬНО 31.10.2026 — поколение 61
1) Have owner confirm the installed speaker actually emits the Russian TTS voice on an actual new reply. 2) Then demonstrate 2/2 and 10/10 consecutive replies, check duplicate suppression, tab switches, cancellation, reload. 3) Once microphone becomes available, test real capture/VAD/ASR separately; do not block TTS. 4) Keep DOM compatibility for legacy and DilResponseRoot and automated regression checks. 5) Preserve local v0.2.61 source and installers; publish to GitHub only after verified release policy, without Actions. 6) Do not use --shutdown, ever, when the GUI owns the active client; GUI PID-only replacement with backup/rollback.

---

## АКТУАЛЬНО 31.10.2026 — менеджер проекта, поколение 60
**Непосредственно далее:** (1) сохранить текущую feature-ветку с незакоммиченными реализациями; не сбрасывать изменения. (2) Проверить состояние USB2.0 MIC, доступность микрофона в NAudio и права Windows; выполнить живое распознавание. (3) Проверить физический TTS и связь с активным WebView2: PTT/continuous, 700 мс VAD, отправка только при правильной настройке, два последовательных обмена, затем 10/10; переключение вкладок, прерывание, отсутствие эха/дубликатов, перезапуск. (4) Провести регрессионный аудит вкладок/вложений/тёмной темы и запись результатов PASS/FAIL. (5) Коммит проверенного кода, сохранение в GitHub (без GitHub Actions). (6) При будущих обновлениях закрывать только GUI по PID; никогда не отключать работающие MCP runtime/tunnel-client через --shutdown. Пользовательская голосовая E2E-приёмка пока **активна**.

---

## Актуально 30.10.2026 — подтверждённый E2E и блокер повторного сообщения
Next: read origin/experiment/thread-relay-host-20261030 docs/MCP-THREAD-RELAY-HOST-EXPERIMENTS-2026-10-30.md and local logs. Reproduce second ui/message ACK/no reply with a NEW isolated canary, not the historical uncertain message. Confirm which ChatGPT conversation actually gets a second user turn; test separate model-only route via ui/update-model-context, never visible user text. After 2/2 then 10/10 and session recovery. Baseline runtime remains v0.2.37; refresh plugin metadata for each new experimental schema. Do not create more tunnels.

## Приоритетное обновление — 30.10.2026, поколение 58
NEXT DECISIVE: One new ordinary ChatGPT chat (one-time acceptance test, not user workflow); check discovery of chat.thread.relay.probe, fresh resource-read, ui-initialize, binding, relay-poll, then one non-sensitive test ui/message and actual chat.reply. Until iframe initialization confirmed, never enqueue a test message. A host-supported automated refresh/reopen is still required for product goal. Report/docs are in branch experiment/thread-relay-host-20261030. Stable baseline is v0.2.37.

## Verified 2026-10-30 live MCP host experiment
READ experiment report in branch origin/experiment/mcp-host-pip-20261030. Main and installed v0.2.37 are stable, experiment was rolled back. Next research MUST target MCP App startup: why tool-open / returned resource URI does not cause chat.ui.pending polling in the active conversation. Thread iframe has real ui-initialize and hidden heartbeat; use this verified property for controlled single ui/message active thread; only real automatic chat.reply counts. Do not retry 2 historical pending+forwarded messages. Explore current resources/subscribe support for event signalling. Leave pip out of basic plan since two real requests returned fullscreen.

## Связь следующего шага с общей миссией
В первую очередь добиться действительного MCP-обмена в обычном ChatGPT без ручного ретранслятора. Архитектура исправления должна оставаться переносимой на другие LLM, несколько независимых компьютеров и будущие голосовые каналы. После 10/10 и подтверждённой работы двух компьютеров — согласовывать приоритеты peer-to-peer/децентрализации, автономного STT/TTS и интеграции Goose/Ollama, не выдавая это за готовый функционал.

## СЛЕДУЮЩАЯ РАБОТА — 30.10.2026
1. Сверить базу v0.2.37, MCP connectivity/Host, очереди и route heartbeat; не использовать секреты профиля WebView2.
2. Исследовать и воспроизвести в обычном ChatGPT механизмы host lifecycle, MCP Apps ui/message, assistant-only контент, sampling и entrypoints. Записывать именно host событие/подтверждение.
3. Создать автоматический MCP round-trip из локального окна с получением chat.reply без ручного вмешательства и без DOM. Не повторять старые pending+forwarded.
4. Проверить новый и существующий чат, 10/10, перезапуск, reconnect, DOMKAT/MKATUSHONOK. Только после этого релиз/продуктовая приёмка. Сохранить VPN Happ, Windows 10 и один туннель.

## 30.10.2026 — v0.2.37 (MCP-only + WebView2 auth)
Next test after v0.2.37 install: sign in once in WinForms WebView2 profile via tray 'Вход в ChatGPT (WebView2)' or local-chat auth button, confirm persistence on restart, without DOM sends. Run one explicit user local chat message; observe MCP Apps automatic start from ChatGPT host tool-result and ui/message target:active; verify hidden assistant annotation and chat.reply return in same local chat. Test new-chat target:new and subsequent bound follow-up. On host close, inspect unacknowledged queue and avoid resend duplicates. Investigate host-approved automatic reactivation; do not substitute browser UI or APIs.

## 30 October 2026: automatic browser transport preview
Next owner action: sign in once to ChatGPT in the separate Yandex Browser window opened by Tunnel. Then send a short message in a new local chat. Manager: check browser-bridge/heartbeat.json mode browser, browser-bridge/events.jsonl and local messages answered, then two consecutive turns, restart continuity, old verified-bound chat, MKATUSHONOK. Keep stable v0.2.35 backup, no Work/Codex/API.

# Next actions

## 2026-10-30: post-release v0.2.35
Owner-authorized controlled installation, then check DOMKAT actual version and MCP connectivity, test two consecutive local messages in a bound ordinary existing ChatGPT conversation, then explicitly new chat from '+ New Chat', then MKATUSHONOK. Confirm replies appear in correct local chat and no other chat is created. Report exact result and retain all local messages. If installation not authorized, do not interrupt v0.2.33.


## 2026-10-30 05:25 MSK: stable v0.2.18 relay restoration
Verify packaged v0.2.30 installation and live two-message ordinary ChatGPT E2E using chat.ui.open and Start; protect old queued messages. Then verify multichat and MKATUSHONOK. Keep new Hub automatic dispatch isolated until stable relay is accepted.


## Следующая версия — указать версию программы в уведомлении (30.10.2026)
- Владелец попросил запомнить: добавить в следующую версию видимый номер **установленной программы** в окно уведомления ChatGPT MCP Tunnel. Отображать версию работающего EXE, без жёсткой константы, не путать с GitHub release или версией исходников.
- Статус: **backlog, не выполнено**. Сейчас не обновлять программу; продолжать при следующем согласованном выпуске. Сохранить STOP, исполнителя и существующее поведение индикатора.

## NEXT — 2026-10-30 ordinary-chat transport
1. After owner installs pre-release v0.2.29, verify installed version and connectivity. Refresh MCP tools and open `chat.bootstrap.open` **from an existing normal ChatGPT /c thread**, not Global. If no deep link was advertised, click its manual confirmation button only after visually verifying ordinary ChatGPT mode.
2. Verify with exactly one controlled local message and actual created ChatGPT thread, then return reply via `chat.reply` and inspect Windows chat receipt. Do not blindly replay four existing old pending messages. If Work appears, record failure and stop routing.
3. No automatic installation from this task. Latest source/release `v0.2.29` (pre-release); installed DOMKAT v0.2.28 as last checked. `docs/ORDINARY-CHAT-ROUTING-2026-10-30.md` has proof and limits.
4. Continue local batch development on DOMKAT, ~1s GUI pacing, STOP, GitHub only storage. Next tasks unrelated to ordinary-chat Work regression remain queued, not silently closed.

## СЛЕДУЮЩИЕ ДЕЙСТВИЯ 30.10.2026, 03:46 MSK
1. После восстановления того же `project-manager` читать актуальное состояние выше, а не исторические «v0.2.28 не готова» ниже. В Git HEAD `ad28e28` и установленная версия DOMKAT `0.2.28+ad28e28`.
2. При следующем взаимодействии с обновлённым MCP инструментом **с явным `executor="project-manager"`** проверить строку «Исполнитель: Менеджер проекта»; в отдельной проверке supervisor и default ChatGPT. Проверить отсутствие путаницы между одновременно работающими чатами. До живого GUI-теста не заявлять полную приёмку.
3. Продолжать проект через локальные пакетные сценарии на `D:\Dev` с fail-fast и коротким результатом; GitHub только исходники/готовые релизы; Actions отключены. Не обновлять автоматически установленную программу: владелец сказал «сам установлю».
4. Будущий технический backlog: разделить в уведомлении исполнение, ожидание модели и истинное завершение; безопасно отменять длинные отдельные сценарии; сохранять E2E нормального ChatGPT без Work/Codex/API.
5. Эта беседа — менеджер `project-manager` v2.1.0. Слово «супервизор» ранее было ошибочной интерпретацией запроса «свою капсулу» и не меняло identity.

## 30.10.2026 — следующие действия по исполнителю
- Локально собрать/проверить release v0.2.28, Git хранение и прямая загрузка assets без Actions.
- После контролируемого обновления и refresh MCP tool catalogue проверять на реальной машине «Исполнитель: Менеджер проекта» при вызове \`executor=project-manager\`, «Супервизор» при \`executor=supervisor\` и «ChatGPT» по умолчанию. Подпись self-declared, не проверенная Host identity.
- Непосредственное состояние «управление завершено / ожидаю модель» остаётся отдельным предложением, не реализовано.

## Следующие действия — 30.10.2026
1. Восстановить того же менеджера по `.context/ENTRYPOINT.md` и integrity seal. Первоочередно читать новую политику `.context/decisions/operating-model-2026-10-30.md` и развёрнутую передачу `docs/PROJECT-MANAGER-HANDOFF-2026-10-30.md`.
2. Беречь **четыре текущие незакоммиченные правки v0.2.28**, проверить Unicode-строки в меню и классификаторе, убрать CS0162, запустить локальные сборки/тесты одним пакетом. Установленный v0.2.27 не заменять без отдельной команды.
3. Дальнейшие задачи — этапы с большим локальным сценарием (план → изменения → проверки → итог); GUI 1s, CLI без задержек; STOP обязателен.
4. Если владелец поручит релиз, только локальный Inno + Git storage/upload, без workflow_dispatch/GitHub Actions.
5. Отдельный backlog: переходы индикатора между действиями, ожиданием модели и истинным концом; STOP для долгих сценариев; ранее открытые ChatGPT MCP Apps E2E.

## 2026-10-30: v0.2.24 return to ordinary ChatGPT instead of Work
1. Publish v0.2.24 verified Windows installers with separate ordinary chat bootstrap tool, observer-only Global, /c-only agent activator.
2. Update DOMKAT, refresh plugin actions; in known ordinary ChatGPT /c conversation invoke chat.bootstrap.open once and verify UI iframe/heartbeat.
3. Save exact /c URL to local hub-entrypoint.url; shut down Yandex and send new local message, no manual browser launch.
4. Verify new cloud chat mode is ChatGPT not Work/Astra (look at composer/model and sidebar), with chat.reply; test continuity and reboot later.

## 2026-10-30: v0.2.23 automatic Windows Global Hub activation
1. Commit/publish v0.2.23 Windows Global Host Activator, verify build/test and SHA-256. Keep v0.2.22 context recovery.
2. DOMKAT controlled update; private hub-entrypoint.url with validated installed Global URL.
3. Close all Yandex Browser; send local message from WinForms without manually opening URL, verify Start-Process by tray, hub ui-initialize, chat.ui.open and chat.reply in correct chat.
4. Check second message context and reply. Follow-up if model fails chat.reply: add server status + one bounded model reminder with dedupe, then retest. Reboot Windows only after basic scenario PASS.

## 2026-10-29: v0.2.22 local chat context recovery after Global cold start
1. Commit/release v0.2.22 context-enhanced Global resource, run CI, controlled install and plugin refresh.
2. Close all Yandex, cold start via Windows Global app URI; remove ACK only for existing failed bdbfca780e364437bd8624eda5d1fa56 so it reenters queue with stored prior answered turn. Observe real reply and status.
3. Test new local chat one-turn and follow-up once more, then lease and host activation, hidden-window reconnect.
4. Keep user-visible surface only WinForms, no special old chat backups, no Work/Codex/API/cloud hourly planner.

## 2026-10-29: v0.2.21 Global Hub cold-start and auto-relay experiment
1. Publish v0.2.21 from source: Global Hub auto-polls unbound chats and ui/message target:new with existing chat.ui.open(chat_id) handoff, test JS/contract.
2. Install verified Windows release DOMKAT, refresh plugins, ensure official URI now hub-relay-v0221.
3. Fully close Yandex, start Global via Windows deep link. Open WinForms chat and send unique test message, no browser interactions. Observe hub-forwarded, ACK and real model chat.reply; follow up.
4. If successful, integrate URI host activator into Windows agent, run minimized host tests and Windows reboot acceptance. Avoid Work/Codex/API/Sign in.

## 2026-10-29: v0.2.20 Global/Thread host compatibility correction
1. CI release v0.2.20 with visible Global/Thread tools and versioned resources; SHA-verify installer, controlled DOMKAT update preserving Chat.
2. Refresh ChatGPT MCP Tunnel plugin tool list; open new global navigation app and a chat thread entrypoint; confirm lifecycle events in Chat/lifecycle-probe/events.jsonl.
3. Attempt deep link and OS-activation test. Verify through ui-initialize and model response only. No Work/Codex/API or hourly automation.

## 2026-10-29: v0.2.19 Global/Thread lifecycle diagnostic implementation
1. Commit and release v0.2.19 (4 new diagnostic tools; 56 total). CI builds and installer preservation tests.
2. Controlled update DOMKAT, refresh ChatGPT MCP Tunnel plugin tool catalogue; use Global navigation and Thread tab with real ChatGPT, inspect sanitized event records.
3. Probe deep link with real plugin ID; test closed-browser OS URI activation and real model reply, then reboot if ready.
4. Ensure existing v0.2.18 messaging still works and user data remains untouched.

## 29.10.2026: normative MCP 2026-07-28, MCP Apps and OpenAI extensions re-analysis
- First: open Global/Thread entrypoints in ordinary ChatGPT (read-only) and instrument UI initialization/host capabilities. Then develop context bootstrap via ui/update-model-context and resources/read; test deep links and OS-level Host activation. Start with source docs/mcp-2026-core-apps-openai-protocol-review-2026-10-29.md. No production changes made during this research.

## 2026-10-29: Deep MCP Apps autonomy research, external GitHub implementations
1. Read full docs/mcp-apps-autonomy-deep-research-2026-10-29.md; validate source citations and record protocols.
2. On DOMKAT perform observation-only global entrypoint and thread entrypoint launch tests in ordinary ChatGPT. Capture tool arguments {}, tool invocation and ui/initialize and host capabilities; don't alter working app release.
3. Test deep-link activation on exact installed plugin ID; verify address launches appropriate Host; then full closed-browser + reboot model response using unique nonce and persisted chat state. Record details.
4. Implement state DB, context capsule, global hub/thread relay, lease/epoch/ACK collision handling only after architecture experiment. Keep no Work/Codex/API.

## 2026-10-29: Study of MCP Apps global and thread entrypoints
- Experiment A: open global via sidebar with {} and inspect actual handshake; B: thread entrypoint in two chats; C: actual plugin deep link with /chat/{id}, no guessed ID. Then propose one-release Hub/Thread architecture and browser-reopen tests.

## 29.10.2026: two distinct live ChatGPT threads and switch-back PASS
- New second local session chat_id 58f8d4f5ab3c4fea88382a4ab029967f received its own new ChatGPT thread via ui/message target:new, route waiting -> ready, and local message 477156c8b341421ebb5866f0bc4188d5 returned Status=answered, Reply=ВТОРОЙ.
- Switched GUI back to first local session chat_id c8d881eb8f0f4ff1aac24dcfe21a0a0c. Message 755051abb067448a9ff138bd2d082371 was forwarded and answered Reply=ПЕРВЫЙ in that same first session. Previous messages ПРИНЯТО and ПРОДОЛЖЕНИЕ remain visible only there. Thus 2 independent new ChatGPT threads, 2 associated local chat histories and switch-back have live end-to-end PASS.
- Browser open, ordinary ChatGPT MCP Apps, no Work/Codex/API or hourly cloud planner. Browser-closed recovery and MKATUSHONOK own local GUI not tested.

## 29.10.2026: v0.2.18 real ordinary ChatGPT multi-chat acceptance PASSED
1. v0.2.18 DOMKAT live MCP Apps relay-v0218, new local chat -> new ChatGPT thread -> chat.reply PASS; next follow-up answered and history switching PASS.
2. Test two separate local chats mapped to separate ChatGPT threads with interleaved user messages.
3. Test MKATUSHONOK local GUI with per-computer origin + reply routing; browser restarts and concurrent iframes.
4. Keep Windows watchdog and existing tunnel; do not re-enable hourly ChatGPT automation or use second tunnel.

## 29.10.2026: v0.2.18 MCP Apps cache-bust after live 0.2.17 test
1. Commit v0.2.18 UI resource cache fix (new ui://.../relay-v0218) and publish verified Windows CI release.
2. Controlled update DOMKAT v0.2.17 -> v0.2.18, ensuring 142+ message files and Windows watchdog intact.
3. In authenticated browser refresh ChatGPT MCP Tunnel plugin tools, open new ordinary ChatGPT chat, invoke chat.ui.open and verify iframe uses new resource/version by displayed status and protocol behavior.
4. Create new local GUI chat, send unique nonce and observe target:new new ChatGPT thread, chat.ui.open(chat_id) bootstrap and chat.reply, no messages in wrong local chat. If host behavior differs, record exact outcome and adapt architecture.

## 29.10.2026: v0.2.17 multi-chat source implemented, pending Windows CI and real ChatGPT
1. Commit approved v0.2.17 source, full Windows CI run plus release and hash checks; keep source manager capsule synced.
2. Install verified v0.2.17 update on DOMKAT, pause watchdog/stop active agent only for installation and re-enable; preserve all Chat directory content, existing Router Lite transport and identities.
3. Browser ChatGPT refresh app tools, open new MCP App in ordinary ChatGPT. Create local chat via GUI, send a real message; confirm ui/message target:new creates new ChatGPT conversation, invokes chat.ui.open(chat_id), automatic forwarding and chat.reply writes into correct local session. Confirm no cross-chat history leak.
4. After acceptance, test MKATUSHONOK using local chat and link server-side routing, then evaluate browser lifecycle persistence and auto-recovery.

## 29.10.2026: REAL ordinary ChatGPT ui/message acceptance 19:36-19:42 MSK
1. Update ChatWindow footer state calculation to use message RepliedUtc and successful ui relay forwarding as stronger evidence of active ChatGPT responses; preserve historic cycle diagnostics separately.
2. Validate actual iframe lifecycle across inactive/minimized browser, closed/reopened browser, thread changes and suspension, with queue recovery tests. No assumption of perpetual background operation.
3. Test MKATUSHONOK local GUI message routing to ordinary ChatGPT and back via MCP.
4. Agree with owner before disabling fallback hourly scheduled chat task. Keep process watchdog.
5. Acceptance evidence codes: manual 58ewppk5, queued 43830fd3, real GUI GUI8C42, inactive tab BGTAB42.

## 29.10.2026: DOMKAT production update 0.2.16 and ChatGPT browser tool refresh
1. Verify action catalog is refreshed in a new ChatGPT turn; check chat.ui.open/52 tools. Do not assume a refresh UI click hot-reloads the tool catalog in a currently executing turn.
2. Call chat.ui.open in ordinary ChatGPT and run user-click 'Тест ui/message' and background 'Начать передачу' separately; validate actual local chat -> ChatGPT -> chat.reply. Report exact host refusal if any.
3. Fix installer to pause watchdog and gracefully stop running agent/runtime before Inno file replacement, then restore watchdog; add live-upgrade test.

## 29.10.2026: v0.2.16 stable Windows release verified (not live ChatGPT accepted)
1. Owner installs Update v0.2.16 from GitHub release and refreshes action list for existing ChatGPT MCP Tunnel plugin.
2. Invoke chat.ui.open, compare «Тест ui/message» immediate user-gesture test with «Начать передачу» automatic relay from local window. Test chat.reply after real model turn and iframe lifecycle. Report exact host error if rejected.

## Next: v0.2.16 diagnostic release and owner UI check
1. Publish stable v0.2.16 with two-case diagnostic and verify Windows GitHub Actions.
2. Owner installs/update DOMKAT and refreshes action catalogue; preserve connection identity and user data.
3. In ordinary ChatGPT invoke chat.ui.open, click «Тест ui/message» and observe a model turn. Then click «Начать передачу», send message in local window; verify auto ui/message + chat.reply. Record whether UI remains active across turns.
4. Until real host test passes, do not promise no scheduler, or unattended availability while UI is closed.

## Immediate next: actual ui/message acceptance
1. Owner installs v0.2.15 update on DOMKAT and refreshes ChatGPT MCP connector actions.
2. Open chat.ui.open in ordinary ChatGPT, enable relay, send a test message through existing local chat.
3. Confirm new model turn, chat.reply and reply visible in local chat; test widget lifecycle and rejection path. Explicitly distinguish confirmed vs hypothetical.
4. Keep existing router/Tunnel ID intact; do not deploy to MKATUSHONOK without approval.

## Next for MCP Apps ui/message v0.2.15
1. Commit source/test/docs with sealed manager generation and run official Windows GitHub Actions installer release; check setup/update/uninstall preservation and status.
2. Provide Windows update link only after release succeeded; do not auto-restart production DOMKAT or remote MKATUSHONOK without explicit instruction.
3. In ordinary ChatGPT refresh plugin tools, invoke chat.ui.open; enable relay and send a local text message. Verify new chat turn and chat.reply actually fires; document refusal/teardown evidence.
4. If host does not permit unattended ui/message from active iframe, retain original queue, report exact rejection and test an MCP-only alternative.

## Next after stable v0.2.14 release
1. Offer published Setup/Update from https://github.com/lvlaksim1/chatgpt-mcp-tunnel/releases/tag/v0.2.14; hashes are recorded in current state.
2. Owner uses built-in updater or verified Update installer on DOMKAT; do not deploy remotely without explicit authorization. Preserve data, TLS pin, keys and one OpenAI tunnel.
3. Test physical file picker, drag-and-drop, pasted screenshot Ctrl+V, attachment-only message, thumbnails/remove, chat history and 49th MCP tool after connector refresh.
4. Verify actual model reads PNG as MCP image and file content via chat.attachment.read. Only then close commitment.

## Next actions: Chat attachments v0.2.14
1. Commit source/tests/docs and sealed manager generation atomically; preserve unrelated untracked files.
2. Run Windows GitHub Actions installer release v0.2.14, verify Setup/Update, installer acceptance, chat GUI/attachment test, protocol and Router Lite regression.
3. Validate release hashes and CI; report factual status.
4. Owner-controlled update of installed DOMKAT/MKATUSHONOK only upon explicit deployment permission. Verify real attachment picker and Ctrl+V screenshot; refresh ChatGPT tools and call chat.attachment.read.
5. Keep commitment active until physical acceptance; no production network/keys/Tunnel ID changes.

## Next after physical large-file WAN acceptance 2026-10-29
1. Physical original-file transfer SUCCESS: MAX.msi 324820992 bytes, full SHA-256 match on DOMKAT, resumed after brief reconnect. Copy exists at C:\Users\Maksim\Downloads\MAX.msi.
2. Maintenance: fix TransferControlPipe.RunClientAsync false nonzero exits on status JSON with error:null or an array listing; test and release.
3. Refresh the attached ChatGPT plugin schema (currently 41 exposed tools, runtime 45 incl. 3 file.transfer tools); v0.2.10 local CLI works already.
4. Optionally validate WinForms transfer window visually in another transfer. Installation of MAX is separate and not part of this acceptance task.


## Priority: publish and deploy v0.2.9 — 29.10.2026
1. Commit code, release v0.2.9 and pass GitHub Actions Windows installer tests.
2. Update DOMKAT and MKATUSHONOK while preserving WSS credentials and TLS pin. Verify the three new file.transfer tools.
3. Copy the original MKATUSHONOK C:\Users\m.katushonok\Downloads\MAX.msi to DOMKAT through Router Lite. Check 324820992 bytes, SHA-256 14A528C373B19B35B3C9E77B5FAEE88DC34A073F15D8801673DDB7C040B2D48F and tray progress.
4. Keep test PASS distinct from physical WAN acceptance; MAX installation is a separate task.


## Next: v0.2.8 direct WSS deployment and actual separate-LAN acceptance — 29.10.2026
1. Owner-controlled DOMKAT Update from verified running v0.2.7 to v0.2.8; keep old cloud Tunnel ID and local Router Lite address unchanged.
2. Configure public IPv4 or domain in Server settings, enable WSS, save/generate PFX and copy verified SHA-256 pin; use a strong 32+ char client key.
3. With owner action and Windows UAC, permit TCP 55202 for router executable, then manually forward public TCP 55202 to DOMKAT LAN TCP 55202. Never forward plaintext 55201.
4. On MKATUSHONOK (different LAN) enter public IP, select secure mode and pin, enter agent key; verify from that physical PC.
5. Validate 23 remote Windows tools, screenshot/UIA and reconnect; record live logs/results and only then close physical acceptance.
- Code: f8cc6684; Release v0.2.8; CI 40781905752 SUCCESS. Existing DOMKAT install not changed.

## Next after verified public WAN IP
1. Present verified feasibility: RT-GM2-3 has public WAN IPv4 matching external Internet egress; IP permanence reported by Owner; no CG-NAT at the router. Exact IP omitted from public repo.
2. Choose with Owner whether to develop self-hosted direct WSS/TLS + strong agent authentication instead of Tailscale. Existing v0.2.7 optional Tailscale solution stays available.
3. Only after secure server is ready and Owner authorizes network changes: configure explicit port forwarding and least-privilege Windows Firewall; never expose existing raw ws:// Router Lite on public WAN.
4. Validate inbound from remote MKATUSHONOK and 23 tools, screenshot/UIA, reconnect. No success claim before actual external proof.
- source: real router WAN IP SOAP and firewall read-only check 28.10.2026.


## Next actions after v0.2.7 release
1. On DOMKAT and MKATUSHONOK install Tailscale from the official Windows package and sign both into one permitted tailnet, completing interactive browser authorization; no public router port forwarding.
2. Read each computer's own 100.x Tailscale IP. Preserve the working OpenAI tunnel; update DOMKAT Agent to v0.2.7 via owner-approved method when ready.
3. In DOMKAT server Settings choose Tailscale interface address as Router Lite listening address (port 55201); then use the new Tailscale firewall button and approve exactly MKATUSHONOK's Tailscale IP in Windows UAC.
4. On MKATUSHONOK set the DOMKAT Tailscale IP, enter protected client key and connect. Observe Tailscale ping, client error classification and actual computer selection.
5. Run real remote tests for files, processes, PowerShell, screenshot, UIA, reconnect. Keep physical acceptance NOT PROVEN until observed success; update manager then.
- Official release v0.2.7 and CI are complete; no re-build needed for the existing scope.


## Приоритет после уточнения владельца: компьютеры в разных сетях
1. Не направлять MKATUSHONOK на 192.168.0.3:55201 без подтверждённого защищённого маршрута между сетями. Не использовать настройку доступа для локальной подсети как решение задачи связи через интернет.
2. Определить с владельцем допустимый сетевой транспорт: предпочтителен простой защищённый VPN (например, Tailscale), альтернатива — отдельный WSS-посредник. Предложение VPN не означает одобрение установки стороннего ПО.
3. Проверить/скорректировать привязку маршрутизатора к VPN-интерфейсу и сетевые ограничения; стандартная кнопка локального брандмауэра v0.2.6 не поддерживает VPN-адреса 100.64.0.0/10.
4. После наличия маршрута выполнить реальную проверку подключения MKATUSHONOK, ключа/имени и работы Windows-команд, экрана, UIA, изображений и переподключения.
5. Сохранить один OpenAI Tunnel ID, один MCP-плагин, текущие установленный DOMKAT v0.2.6 и локальную конфигурацию; без несанкционированной установки/проброса публичных портов.
- source: прямая поправка владельца и репозиторий Router Lite 28.10.2026.


## Current execution priority — 28.10.2026 22:20 MSK
1. Do not re-install v0.2.6: installed and running agent FileVersion 0.2.6.0 is verified.
2. Check server LAN firewall permission and current client key through approved UI/secure procedure; owner authorizes any UAC firewall operation; do not disclose secrets.
3. Connect real MKATUSHONOK client to 192.168.0.3:55201; inspect state/logs and distinguish network, 401 authorization and 409 duplicate-name errors.
4. On verified connection, exercise machine-targeted remote Windows file, shell, screenshot, UI Automation and reconnect; check 41 vs 42 tool exposure.
5. Persist cross-host evidence and conclude acceptance only after positive tests; preserve original cloud tunnel identity, current IP and live installed application.
- source: verified live DOMKAT and published v0.2.6 28.10.2026.


1. Prepare and test installation of Router Lite agent on a **second physical Windows computer**, using a protected private network (or WSS/TLS). Do not expose plain WebSocket with secret to the internet.
2. Verify physical PC identification, 23 tools, remote screenshots, UIA, machine-specific paths, reconnect and errors; run full regression on DOMKAT again before live replacement.
3. Add simple agent provisioning, protected local secret storage and Windows sign-in autostart, while retaining one binary/repository/plugin and avoiding a database.
4. Update launcher for explicitly configured Router Lite; release a stable numerical version only after acceptance, update manager capsule and document real cross-host evidence.

Stages 1–3 were completed and locally verified on DOMKAT; do not repeat that work without a regression or new finding. Source: Owner task and verified tests (28.10.2026).

5. Publish agent installer source in `main`, trigger Windows GitHub Actions release workflow for numeric v0.1.0, inspect output/repair failures until Setup and Update EXE are published. Verify installation, update preservation and uninstall.
6. After binary release, configure DOMKAT Router Lite and connect a second Windows PC via a protected network; perform physical multi-PC acceptance.

## Folder acceptance
- Compile and validate both role-specific paths and custom folder preservation in Windows CI; publish universal installer when passing.
- Do not remove the existing DOMKAT tunnel until the new installation and independent recovery procedure are verified. The Owner will input a new token for the clean installation.

## Next after v0.2.0 release
- Prepare a safe autonomous transition of DOMKAT from the old running tunnel to clean Server v0.2.0 installation without preserving the old credentials; let owner enter a new token directly in the UI.
- This transition will terminate the MCP channel. Ensure a recoverable local installer and startup procedure are present before shutting down the old tunnel.
- Then connect MKATUSHONOK as Client via the sole DOMKAT router and verify remote controls across physical PCs.

## Next existing-tunnel migration
- Publish and validate Windows v0.2.1 installer with PowerShell syntax checking and without new-cloud-tunnel API calls.
- Stage verified installer with Prepare-Clean-Reinstall-DOMKAT.ps1, preserving only existing Tunnel ID.
- Run independent Start-Clean-Install.cmd to remove old local files and install server; Owner enters token in new program.
- Verify connectivity of same ChatGPT plugin and MKATUSHONOK remote tools.

## Next after live repair
- Commit and build numerical v0.2.2 with safe native stderr handling via Windows installer CI, verify release assets.
- Preserve existing DOMKAT setup, token and Tunnel ID; do not clean-reinstall again.
- Connect MKATUSHONOK to 192.168.0.3:55201/agent in the protected local network using its own agent key and verify cross-host tooling.

## After verified v0.2.2 deployment
- Configure and test MKATUSHONOK as Client of existing DOMKAT Router Lite, endpoint ws://192.168.0.3:55201/agent on the trusted LAN, using the existing locally stored agent-specific connection key.
- Check Windows Firewall trusted-network reachability and do not expose ws to public Internet.
- Verify remote system.info, files, screenshot and UI Automation against MKATUSHONOK with no extra OpenAI tunnel. Preserve current DOMKAT release and working plugin.

## v0.2.3 rollout
- Commit source and original ICO, build/test full and update installers in Windows GitHub Actions, publish v0.2.3.
- Update DOMKAT in-place using verified installer while retaining one original OpenAI Tunnel ID and protected keys.
- Verify tray icon and green connected marker, correct «Сервер подключён» tooltip and Settings window via menu and --settings.
- After UI acceptance return to physical MKATUSHONOK client tests.

## v0.2.4 native visible settings
- Run Windows GitHub Actions installer build and update acceptance for v0.2.4, publish stable binaries.
- Verify SHA256 and update DOMKAT in place, preserving existing Tunnel ID/DPAPI keys.
- Run installed --settings and confirm desktop.window.list finds visible foreground Server Settings window without any external ShowWindow command; test reopen and successful server state.
- Then continue remote MKATUSHONOK acceptance.

## Release deliverable
- Commit v0.2.5 source and approved manager capsule, dispatch Windows Actions release, confirm run success.
- Verify GitHub release includes full ChatGPT_MCP_Tunnel_Setup_v0.2.5.exe and update ChatGPT_MCP_Tunnel_Update_v0.2.5.exe with SHA256 digests; built-in updater compatibility should be preserved.
- Provide links only, do not install/upgrade the active DOMKAT server. Wait for owner self-update and further acceptance feedback.

## After release
- Provide links for full Setup and Update v0.2.5 and report successful CI.
- Do not install on DOMKAT. Owner updates existing app themselves using built-in updater.
- Upon owner confirmation, inspect updated app and follow up only with requested UI fixes; keep existing OpenAI Tunnel ID, DPAPI secrets, IP 192.168.0.3.

## Deliver v0.2.6 repair binaries
- Commit source+manager capsule, dispatch Windows installer workflow for v0.2.6, verify all tests, 2 Release EXEs and SHA256.
- Explain one-time manual update necessary from installed v0.2.5; subsequent in-app updates repaired.
- Leave installed DOMKAT version, keys, tunnel, IP 192.168.0.3 untouched.

## v0.2.6 client connectivity follow-up
- Publish both full/update installers with Windows tests for staging, firewall subnet calculation and client WebSocket error states.
- User self-installs v0.2.6, uses Server Settings «Разрешить доступ клиентам в локальной сети» then Windows UAC confirmation; client's IP/hostname and shared key are entered separately, save/connect.
- Confirm connectivity from physical client. If still failing, gather its on-machine agent.log/error (network vs 401 vs 409), do not speculate.

## Post-release manual owner tasks
- Owner self-installs v0.2.6 Update on DOMKAT.
- In server Settings use LAN-only firewall permission button, accept UAC, copy current server client key.
- On MKATUSHONOK use server address 192.168.0.3, enter copied key and save/connect. Observe client status; on failure distinguish network, 401 key, 409 name and gather client logs.
- No remote DOMKAT upgrade by project manager; do not change cloud Tunnel ID, DPAPI secrets, IP.
