## GEN 74 — обязательства при дальнейшей разработке (31.10.2026 21:27 МСК)
Не перепутать режимы компьютеров: DOMKAT — сервер и Happ по умолчанию; MKATUSHONOK — Router Lite client с WebView2 через только Free Xray. Не создавать второй профиль ChatGPT, второй официальный MCP tunnel-client на MKATUSHONOK, не выключать системный Happ на DOMKAT. Не размещать браузерные данные, приватные VLESS параметры или DPAPI-профили в публичном GitHub.

---

## VPN operation stable v0.2.65 (31.10.2026 20:24 MSK)
Preserve one authenticated ChatGPT WebView2 profile on DOMKAT and one MCP tunnel-client. Rotate validated backups first, return to Happ only if none work, notify operator. GitHub is version storage; never upload DPAPI or browser backups.

---

## v0.2.65 operator intent (31.10.2026 20:18 MSK)
Use standby free nodes first after forced main-node failure; only fallback Happ if no verified backup. Notify via Windows Tray; keep one authorized profile, no global VPN changes, no extra MCP client, preserve connected Router Lite clients.

---

## Single-profile VPN owner requirement (31.10.2026 19:40 MSK)
Use exactly the original ChatGPT signed-in WebView2 UDF for Happ and Free Xray; browser processes must fully exit between proxy-option changes. Keep Happ safe fallback and free node automatically revalidated on change; never recreate a separate empty browser login.

---

## VPN acceptance priorities — gen 70 (31.10.2026 18:58 MSK)
Maintain coherent UI/server mode and safe app-specific networking. Trust of public free nodes remains unknown; default and fallback Happ. Current MCP and Router Lite stable.

---

## DOMKAT MCP VPN mode goals (31.10.2026 18:10 MSK)
Keep server-only full-app routing via a stable local HTTP proxy; allow native official tunnel-client to reconnect persistent transport when mode changed, without restarting MCP runtime or Router Lite clients. Happ stays initial mode. Preserve sensitive traffic until owner elects untrusted public Free mode.

---

## VPN mode intentions (31.10.2026 17:08 MSK)
Keep Happ as default/backup; allow explicit free Xray mode for isolated browser only. Continue work towards mode covering the full app including official MCP transport after verification, without extra tunnel or automatically exposing authenticated browser data to free public nodes.

---

## Free node updater intention (31.10.2026 16:36 MSK)
Treat automatic fresh server discovery, validation, dedup, ranking and DPAPI persistence as functional. Do not silently switch signed-in ChatGPT to public proxies; auto-rerouting an active session remains a separate option requiring owner choice and validation.

---

## Free VPN intention, generation 65 (31.10.2026 14:33 MSK)
Test public free VLESS/REALITY as non-production route; preserve privacy of existing ChatGPT and do not auto-switch sensitive sessions or permanent tunnel transport without owner decision. Seek trusted long-lived independent endpoint for stable production replacement.

---

## LamaVPN intent (31.10.2026 14:12 MSK)
Continue legitimate reuse of paid subscription via authorized standard profile; preserve Happ as fallback until independent proxy genuinely passes WebView2+MCP E2E. No credential decrypt/redistribution or production switch without working provider data.

---

## VPN intention (31.10.2026, 13:30 MSK)
Achieve dependence-free app-scoped VPN using Xray-core as replaceable engine, with separate per-process proxy routing, no OS-wide changes, one MCP tunnel and safe fallback to current Happ until verified.

---

## Намерение: поколение 62, 31.10.2026, 12:32 MSK
Считать функционал физического TTS на колонках принятым пользователем. Сохранять независимость озвучивания ответов от микрофона; сфокусировать дальнейшие испытания ввода на времени появления микрофона.

---

## ACTIVE 31.10.2026 — project-manager generation 61
Continue independently deliverable TTS even with no microphone. v0.2.61 installed, modern DIL response DOM support added. Physical speaker and sustained real-chat auto-voice acceptance still active; microphone-dependent STT deferred, not failed. Preserve seven strategic goals and one tunnel.

---

## АКТУАЛЬНО 31.10.2026 — менеджер проекта, поколение 60
Owner-accepted 31.10: полноценное автономное локальное голосовое общение Sherpa-ONNX поверх действующего ChatGPT WebView2. Подзадачи сборки, установки, офлайн ASR/TTS и mock DOM завершены/проверены. Оставшееся обязательство — реальные тесты физического микрофона, голосовой отправки, озвучивания ответа и устойчивости — **active, not completed**. Прежняя MCP Apps-only стратегия была **superseded** прямым указанием владельца; не возвращаться к ней. Хранить 7 стратегических целей и условия Windows 10, Happ включён, один туннель, без отдельных платных API.

---

## Актуально 30.10.2026 — подтверждённый E2E и блокер повторного сообщения
Investigate why a second ui/message target=active got an ACK without generation or chat.reply while the iframe kept running. Independently replace user-visible routing text with tested model-only MCP Apps context (candidate ui/update-model-context). Do not use DOM, Work, Codex, or a separate API. Do not resend ambiguous pending+forwarded messages. Refresh dev plugin metadata whenever tool definitions or resource URI changes, before starting a new diagnostic conversation.

## Приоритетное обновление — 30.10.2026, поколение 58
Next action: Compare freshly created ordinary ChatGPT conversation with old cached context after MCP plugin refresh. Test real creation of the new thread-relay-probe tool and fresh resource-read. If fresh schema works, then controlled one-message queue->ui/message->chat.reply; then research host lifecycle/recovery. Do not blindly change UI transport or make cosmetic releases.

## Verified 2026-10-30 live MCP host experiment
Current priority after live PIP test: focus on reliable host activation and first genuine local-chat -> ui/message -> chat.reply round-trip. Do not build main transport on pip: tested twice, fullscreen returned. Hidden iframe heartbeat is promising for a live relay but not enough. Explore normal Thread Entrypoint lifecycle, subscriptions on MCP resources and explicit host capabilities; do not treat synthetic tests, tool-open, or manual chat.reply as accepted.

## Намерение менеджера по стратегическим целям — 30.10.2026
Удерживать семь согласованных целей проекта одновременно: (1) MCP-управление Windows, (2) несколько компьютеров и передача файлов, (3) децентрализация узлов, (4) автономный двусторонний локальный чат, (5) независимая бесплатная голосовая связь, (6) универсальность для ChatGPT/Goose/Ollama/других LLM, (7) безопасность, бесплатность и удобство. Текущий P0 — доказанный автоматический MCP-чат, но не переписывать миссию всей системы как «создать чат». У любого нового решения проверять совместимость с равноправными узлами, общим MCP-слоем и будущими моделями, не внедряя ненужные зависимости.

## ТЕКУЩЕЕ НАМЕРЕНИЕ — 30.10.2026
1. Не считать v0.2.37 завершением функции чата: это инфраструктурный промежуточный релиз, установленный на DOMKAT.
2. Исследовать именно официальные возможности MCP Apps и OpenAI extension: host lifecycle, global/within-conversation entrypoints, ui/message, tool-input/result, teardown, sampling. Практически проверить способы автоматической host-активации.
3. Добиться настоящего автономного цикла: локальный текст → обычный ChatGPT → ответ через chat.reply в исходное окно, без ручного действия перед каждым сообщением.
4. Сохранить неопределённо отправленные сообщения; без доказанного ACK/ответа не дублировать их. Сначала сквозной тест, затем 10/10 и многокомпьютерная приёмка.
5. Не возвращаться к отвергнутым DOM/Node/CDP/API/workaround, не маскировать блокер новыми экранами и релизами.

## 30.10.2026 — v0.2.37 (MCP-only + WebView2 auth)
2026-10-30: Continue MCP-only messaging; WebView2 is for persistent login only. Do not reintroduce BrowserChatBridge.js, DOM injection, synthetic ChatGPT replies or separate model API. Research the official host lifecycle capabilities and verify real normal ChatGPT browser/host mode; prioritize user chat convenience and stable connections.

## 30 October 2026: automatic browser transport preview
Current intention 2026-10-30: accept browser-based normal ChatGPT chat only after one-time login and genuine two-turn local roundtrip, then multi-chat/restart/remote-computer test. Avoid requiring per-message chat.ui.open. Do not assert fully automatic until live tested.

# Manager intentions and commitments

## 30 Oct 2026: v0.2.35
Completed and verified: local source correction, packed tests, direct stable GitHub release v0.2.35, full/update installers and SHA256. Active: install with Owner authority and confirm actual ordinary ChatGPT new/existing dialogue continuity with two turns and reply in local window. Active backlog: robust updater with confirmed reconnection/rollback, not claimed completed.


## 2026-10-30 05:25 MSK: stable v0.2.18 relay restoration
Complete local restoration of v0.2.18 manual relay and v0.2.30 packaging, then safely install and run genuine two-turn E2E in an existing ordinary ChatGPT conversation. Only after live acceptance investigate robust automatic activation. Never route through Work or Codex.


## 30.10.2026 — запрос владельца: номер версии в интерфейсе
- **accepted/backlog:** в следующей версии ChatGPT MCP Tunnel показать **номер установленной версии программы** пользователю. В контексте обсуждения индикатора управления предполагается отображать его непосредственно в окне уведомления об управлении (например, `ChatGPT MCP Tunnel · vX.Y.Z`). При реализации брать версию из метаданных установленного исполняемого файла/сборки, **не** жёстко зашивать текущий номер.
- Эта задача **ещё не реализована** и **не требует немедленного выпуска или установки**. Владелец сказал: «на будущее запомни — добавить в новую версию указание версии программы».

## 2026-10-30 04:14 MSK — active ordinary-chat routing commitment
- **completed (code + packaging):** compare v0.2.18 and current routing, separate Global observer from ordinary dispatcher, block unsupported/unsafe host contexts, add explicit one-time confirmation when normal-chat route metadata is unavailable, run local Windows/MCP/Router Lite/Node regression, publish candidate `v0.2.29` directly to GitHub Releases (pre-release; no Actions).
- **accepted/active (user-facing acceptance):** after user installs candidate, invoke `chat.bootstrap.open` **inside a visually verified ordinary ChatGPT conversation**, confirm mode when button appears, send one controlled local test message, inspect resulting conversation UI for ordinary Chat rather than Work, verify `chat.reply` returns a local reply. Acknowledgement of ui/message is insufficient.
- **active constraints:** do not consume or erase the four existing pending local messages during diagnostics, do not silently submit them to Work. Do not install new build without owner instruction (owner previously said "сам установлю"). Do not switch to Work/Codex/API, do not enable GitHub Actions, do not disable Happ.
- If real host cannot guarantee new ordinary conversation, keep blocker open and analyze with host lifecycle evidence rather than claiming solved.

## Статус обязательств 30.10.2026, 03:46 MSK
- **completed/verified:** исправление Unicode `????` в исходниках, персонализированный исполнитель на уровне вызова, локальные сборки и регрессии `v0.2.28`, коммит `ad28e28`, GitHub Release `v0.2.28`. Установленная 0.2.28 на DOMKAT проверена; установку произвёл владелец. Старые «active: выпустить v0.2.28» ниже **завершены**, не запускать повторную публикацию или установку.
- **accepted/active для приёмки:** проверить фактическое отображение «Исполнитель: Менеджер проекта», «Исполнитель: Супервизор», «Исполнитель: ChatGPT» на установленном агенте после того, как ChatGPT увидит обновлённую схему MCP-инструментов. Само наличие 0.2.28 и unit-тесты не эквивалентны пользовательской GUI-приёмке.
- **proposed/backlog:** явные стадии «выполняю действие / ожидаю решение модели / задание действительно завершено»; расширенная отмена самостоятельных локальных фоновых сценариев кнопкой STOP. Не отмечать как реализованные.
- **owner-instruction:** роль текущего разговора — `project-manager`; не объявлять себя супервизором, не менять persistent identity. Пакетная разработка и GitHub storage-only продолжают действовать. Ранее незавершённые обычный ChatGPT/MCP Apps E2E и многокомпьютерный чат не закрывать без проверок.

## 30.10.2026 — маркировка исполнителя (active until deployed)
- accepted/active: deliver user-requested executor line in the Windows control notification; per-call project-manager/supervisor or default ChatGPT, including remote and GUI batch; no global cross-chat leakage.
- Source and integration tests v0.2.28 are locally passing. Release/production installation and host tool refresh are not yet proven; do not mark completed until verified.
- Fix literal Russian UI question marks from the preceding v0.2.28 work in the same release; preserve previous owner directions on local build only.

## Действующие намерения после решения владельца 30.10.2026
- **accepted/active:** исправить кириллические `????` в tray и классификаторе действий и проверить `v0.2.28`; текущие четыре незакоммиченные правки беречь. Устранить CS0162, проверить GUI-сообщения и регрессии. Не заявлять выпуска до успешных тестов/релиза.
- **accepted/active:** перейти к выполнению целыми локальными пакетами по требованию владельца; сокращать время между мелкими действиями без потери контроля безопасности.
- **proposed/backlog:** добавить фазы индикатора «выполнение на ПК / ожидаю модель / действительно завершено»; пока не реализовано. Доработать отмену самостоятельных долгих CLI-сценариев.
- **completed:** создана главная папка `D:\Dev`, отключены все GitHub Actions, локально выпущена `v0.2.27`, выполнено автоматическое обновление DOMKAT с восстановлением связи.
- Старые открытые обязательства о живой приёмке обычного ChatGPT MCP Apps/Router Lite остаются до доказанного E2E; отдельные шаги «запустить GitHub CI» **superseded** и не должны исполняться.

## 2026-10-30: v0.2.24 return to ordinary ChatGPT instead of Work
- Deliver v0.2.24 fix for unwanted Work/Astra threads. Create/publish verified Windows release, provision one model-invoked bootstrap MCP iframe in ordinary ChatGPT, set Windows anchor URL /c/<uuid>, cold-start browser and verify new threads remain ordinary ChatGPT, not Work. No Work/Codex/API consumed by tunnel transport.

## 2026-10-30: v0.2.23 automatic Windows Global Hub activation
- Finish autonomous cold start: v0.2.23 Windows tray activates previously validated Global Hub when local queue needs a model and no Global heartbeat exists. Preserve v0.2.22 context transfer, verify real replies and continuity. Use ordinary ChatGPT MCP Apps only, without Work/Codex/API or user browser interaction.

## 2026-10-29: v0.2.22 local chat context recovery after Global cold start
- Validate v0.2.22 cross-thread context recovery with real local Windows messenger and model. Keep browser invisible to user while running host in background; don't promise inference with browser.exe=0. Ensure stale/orphaned cloud replies eventually recover, then implement per-hub instance lease and automatic URI Host Activator.

## 2026-10-29: v0.2.21 Global Hub cold-start and auto-relay experiment
- Prove completely unattended handoff from Windows local chat to normal ChatGPT and back, using Global MCP App auto-relay. Browser executable may be started by Windows, but no user browser interactions permitted. Keep one tunnel; no Work/Codex/API/Sign in with ChatGPT/cloud planner.

## 2026-10-29: v0.2.20 Global/Thread host compatibility correction
- Complete v0.2.20 Global/Thread entrypoint real ChatGPT experiment with compatibility metadata; verify iframe event log and test direct OS deep link. Keep the local Windows messenger the sole product UI and preserve all v0.2.18 chat functionality.

## 2026-10-29: v0.2.19 Global/Thread lifecycle diagnostic implementation
- Run experimental Global/Thread entrypoint lifecycle in ordinary ChatGPT after v0.2.19 verified installer. Do not conflate static entrypoint tool-open with successful iframe initialization or model answer. Do not replace user chat with MCP panels. Keep Windows messenger only user UI. Preserve existing relay and all history.

## 29.10.2026: v0.2.18 real ordinary ChatGPT multi-chat acceptance PASSED
- v0.2.18 new-chat handoff and continuing responses now live-accepted in ordinary ChatGPT. Next harden recovery when browser closes, concurrent iframes and routing across remote MKATUSHONOK. Preserve disabled hourly cloud automation.

## 29.10.2026: v0.2.18 MCP Apps cache-bust after live 0.2.17 test
- Publish v0.2.18 as cache-busting MCP Apps resource update, verify CI release, deploy DOMKAT, refresh browser tool catalog and test real ui/message target:new handoff. Local multi-chat UI from 0.2.17 already working in production, cloud new-chat handoff not yet empirically accepted.

## 29.10.2026: v0.2.17 multi-chat source implemented, pending Windows CI and real ChatGPT
- Deliver v0.2.17 with a usable per-computer multi-chat WinForms UI and MCP chat_id model without disturbing legacy history. Keep automatic target:new handoff experimental until actual ordinary ChatGPT acceptance.
- Publish/verify Windows Setup and Update CI, deploy cautiously to DOMKAT using independently verified update, refresh tool catalog (tool count remains 52), test real new-chat transfer from GUI and chat.reply. Do not reenable hourly cloud automation; preserve Windows tunnel watchdog.

## 29.10.2026: REAL ordinary ChatGPT ui/message acceptance 19:36-19:42 MSK
- Live ui-message-2026-10-29 active host acceptance now PASS on DOMKAT 0.2.16 for manual, queued, real GUI, background-tab. Commitment remains OPEN for persistent iframe lifetime and reliable always-available behavior when browser closed/suspended.
- Fix misleading local chat footer and verify remote MKATUSHONOK GUI roundtrip in next phase. Hourly task may be disabled only after owner decision and full persistence acceptance.

## 29.10.2026: DOMKAT production update 0.2.16 and ChatGPT browser tool refresh
- commitment ui-message-2026-10-29: DOMKAT installation 0.2.16 and explicit owner-requested browser action refresh now DONE. Remaining goal: real ChatGPT chat.ui.open availability in fresh host session, user-click ui/message versus automatic local queue, chat.reply, lifecycle behavior; claim no scheduler only after live proof.
- Maintain separate issue: updater should automatically coordinate agent/watchdog shutdown to avoid silent Inno exit 5 on an active installation.

## 29.10.2026: v0.2.16 stable Windows release verified (not live ChatGPT accepted)
- v0.2.16 Windows CI/release complete (40907216014 SUCCESS). Commitment remains ACTIVE until owner installs and refreshes connector, then validates user-click and automatic ui/message separately in real ordinary ChatGPT.

## ui/message v0.2.16 diagnostic version pending production acceptance
- commitment: ui-message-2026-10-29, active. Build/release extended probe, require physical owner update and refresh ChatGPT MCP actions, then test explicit-click message and timer-based queue forwarding separately. Do not claim either real behavior tested yet; preserve existing one-tunnel network.

## v0.2.15 release completed — real host acceptance still active
- Source, simulation, Windows installation and release checks completed. Main commitment remains active until real ordinary ChatGPT host accepts the timer-initiated ui/message and sends reply via chat.reply. Do not confuse successful GitHub Actions with real ChatGPT behavior.

## MCP Apps ui/message experiment accepted 29.10.2026
- commitment_id: direct-chat-ui-message-2026-10-29. Owner authority: explicitly implement MCP-only ui/message.
- status: active; prototype and local simulated-host verification done, stable CI release and LIVE ChatGPT host acceptance remain.
- objective: send user message from existing local GUI to ordinary ChatGPT through MCP tools and ui/message, no scheduler, other API, Codex or Work. Existing OpenAI tunnel and Router Lite preserved.
- no completed claim unless actual ordinary ChatGPT ui/message invokes a new turn, invokes chat.reply, and the reply appears in local chat.

## Chat attachments v0.2.14 — CI/release complete, physical acceptance active
- commitment_id: chat-window-attachments-2026-10-29
- state: source/local tests and GitHub Windows Setup+Update stable release v0.2.14 COMPLETED, 40866882778 SUCCESS.
- active remaining responsibility: owner-controlled installed update, real clipboard screenshot insertion and file attachment send, live ChatGPT read of actual image through refreshed plugin schema.
- Do not alter installed DOMKAT/MKATUSHONOK or network credentials under this release-only step. Source: verified CI and GitHub Release 29.10.2026.

## Chat attachments v0.2.14 — accepted 29.10.2026
- commitment_id: chat-window-attachments-2026-10-29
- status: accepted/active; source implementation and local tests completed; release and physical owner-facing acceptance pending.
- owner: project-manager. Source: direct owner order 29.10.2026.
- outcome: file picker, multi-attachments preview/remove, Explorer drag/drop, Ctrl+V clipboard images, text+files or files-only message, MCP reading as real image/text blocks and local verified path for binary documents.
- completion gate: stable Windows CI/installers, owner-controlled deployment, physical Ctrl+V and file selection verification, ChatGPT tool catalog refresh and native attachment read; preserve OpenAI tunnel identity and network configuration.

## Direct WAN deployment and physical acceptance, 29.10.2026
- commitment_id: direct-wan-wss-2026-10-29
- status: code, local tests and stable v0.2.8 release completed; owner-controlled physical deployment and verification remain active.
- owner: project-manager
- Решение владельца 29.10.2026: DOMKAT имеет статический публичный IPv4 на WAN-интерфейсе маршрутизатора; удалённый клиент расположен в другой локальной сети. Развивается прямой защищённый WSS без обязательного Tailscale/посредника. Локальный адрес DOMKAT не заменяется внешним IP. Источник: прямая команда владельца; код основной ветки f8cc66848a475030b63ad5c15e25ec6c68e76308.
- Remaining: verify server/local IP, install v0.2.8 through Owner-controlled updater; configure WAN rule and router TCP 55202 forwarding on explicit Windows/router interaction; transfer and independently verify SHA-256 certificate fingerprint and 32+ character key; test MKATUSHONOK from separate network, all 23 remote Windows functions, screenshots/UIA, reconnect, invalid cert/key. Do not close before live proof.

## Direct WAN option after validated public router IP
- commitment_id: compare-direct-wss-vs-vpn-2026-10-28
- status: read-only feasibility verified; adoption pending Owner decision; no changes to server/router/firewall.
- Reassess need for Tailscale/Headscale/VPS because DOMKAT router has a verified public WAN IPv4; design secure WSS or equivalent cryptographic channel and authenticated agents before public inbound exposure.
- Explicitly keep production unchanged until new transport is selected/tested; retain v0.2.7 Tailscale feature as fallback.
- source: owner static-IP statement, verified router GetExternalIPAddress and NAT/firewall inspection 28.10.2026.


## Tailscale Router Lite integration v0.2.7
- commitment_id: tailscale-cross-network-v027-2026-10-28
- status: implementation/release completed; physical deployment and client E2E acceptance active
- verified: v0.2.7 CI run 40756470762 success, Setup/Update available, local Windows and router tests passed. One client IP is authorized per explicit firewall confirmation; LAN compatibility retained.
- remaining: Tailscale installation/sign-in on BOTH physical PCs, owner-side in-place update of DOMKAT if desired, Tailscale IP binding, peer-specific firewall rule, key entry, real MKATUSHONOK connection, 23 remote Windows tools and reconnect acceptance.
- source: owner execution command, GitHub commit c04e2ec, Windows CI 40756470762, Release v0.2.7.
- Do not claim working inter-network link before observed remote test; do not modify installed DOMKAT or IP/Tunnel ID through manager.


## Межсетевое соединение компьютеров — уточнённое обязательство
- commitment_id: cross-network-transport-after-owner-correction-2026-10-28
- status: active; технический способ ещё не согласован, проверка двух физических компьютеров не выполнена.
- Установленный владельцем факт: DOMKAT и MKATUSHONOK находятся в разных локальных сетях. Сохраняем один OpenAI MCP Tunnel и Router Lite.
- До подключения MKATUSHONOK необходимо спроектировать безопасный межсетевой транспорт. Рекомендуемый для проверки вариант — виртуальная зашифрованная сеть; альтернативой является защищённый WSS-посредник. Не считать одну кнопку LAN-брандмауэра решением.
- source: прямая поправка владельца и проверка кода v0.2.6 28.10.2026; authority: owner-directive, verified-repository.


## Post-install physical client acceptance (28.10.2026 22:20 MSK)
- commitment_id: physical-client-acceptance-after-v026
- status: active; installed v0.2.6 verified on DOMKAT, cross-machine acceptance NOT PROVEN.
- remaining: check authorized LAN firewall exception and current client key, then demonstrate MKATUSHONOK connection, remote Windows tools/UIA/screenshot and reconnect; reconcile 41 visible/42 advertised tools.
- source: live read-only process/version/TCP checks and original Router Lite owner commitment; authority: verified-runtime, owner-directive.
- Do not re-install remotely, change Tunnel ID/IP/credentials, or expose keys.


## Router Lite implementation
- commitment_id: `router-lite-2026-10-28`
- status: accepted/active
- owner: Project Manager `project-manager`
- source: Owner 28.10.2026: «восстанови менеджера проекта chatgpt-mcp-tunnel. передай ему всю эту информацию и пусть приступает к разработке».
- authority: owner-directive
- outcome: one MCP tunnel with explicit computer selection and remote execution of the existing Windows tools.
verified partial progress: stages 1-3 passed local E2E, all 23 Windows tools remote-capable, PNG preserved, parallel calls, bad keys, duplicate IDs, reconnect, old Windows/GUI/UIA regressions passed.
- remaining: cross-machine verification on second physical PC, protected agent provisioning/autostart, operational acceptance and release validation.
- completion gate: functional second physical PC and regression of all 41 original tools; explicit verification, no completion claim from local-only test.

## Maintain independent core plugin
- commitment_id: `independent-mcp-tunnel`
- status: accepted/active
- outcome: preserve the independent project, launcher, GitHub tools and existing Windows capabilities during incremental changes.
- source: prior Owner decisions recorded in `.context/project/*` and repository README.
- authority: owner-directive.


## Agent installer and updater
- commitment_id: `agent-installer-2026-10-28`
- status: accepted/active
- owner: Project Manager `project-manager`
- source: Owner explicitly accepted the MailRu Desktop installer architecture for Router Lite and ordered implementation on 28.10.2026.
- authority: owner-directive
- outcome: a self-contained x64 per-user Windows agent with two Inno Setup installers, DPAPI credentials, tray interface, user-session autostart and GitHub Releases updates.
- verified partial progress: application and runtime built self-contained on DOMKAT; `--selftest` and 42-tool/router/reconnect smoke tests passed; installer source/workflow are written.
- remaining: second physical PC connection, protected network and real cross-host GUI/shell acceptance.
- completion gate: valid downloadable Setup and Update installer assets, CI acceptance, then physical network operation validated separately.

## Installation directory commitment
- commitment_id: install-directory-2026-10-28
- status: accepted/active
- owner: project-manager
- source: Owner requested custom folder selection and role-based D/C defaults on 28.10.2026.
- authority: owner-directive
- verified partial progress: source implementation and CI assertions complete.
- remaining: Inno Setup compile, Windows CI acceptance and stable universal installer release.

## Outcome of universal installer v0.2.0
- Source-complete and CI-verified: universal Setup/Update v0.2.0 released; verified default and custom paths, update preservation and installer cleanup.
- Remaining commitment: clean migration of DOMKAT and cross-host acceptance with MKATUSHONOK, not additional installer design.
- source: GitHub Actions 40696034380, Release v0.2.0, Owner instructions.
- authority: verified-repository, owner-directive.

## Clean local reinstall without creating any OpenAI tunnel
- commitment_id: clean-domkat-same-tunnel-2026-10-28
- status: accepted/active
- owner: project-manager
- source: Owner requested clean DOMKAT installation and token entry, then explicitly confirmed all operations must use the existing OpenAI tunnel.
- authority: owner-directive
- outcome: preserve the logical Tunnel ID, erase old local auth, install new server and enter new token in the UI; do not create another OpenAI tunnel.
- verified partial progress: removed new-cloud-tunnel code, local x64 .NET selftest passes, autonomous staging and cutover scripts written and PowerShell syntax validated.
- remaining: release CI v0.2.1, prepare verified installer staging, actual clean cutover and remote client acceptance.

## Permanent fix for server launcher
- commitment_id: recover-domkat-native-stderr-2026-10-28
- status: accepted/active
- owner: project-manager
- source: Owner requested independently checking/fixing DOMKAT using restored Desktop Commander.
- authority: owner-directive
- verified partial progress: production hotfix restored same tunnel; tests of bridge_ping, Windows/GitHub tools and Router Lite passed; source fixed.
- remaining: build and publish fixed installer v0.2.2, then connect MKATUSHONOK remotely.

## v0.2.2 recovery complete
- commitment_id: domkat-native-stderr-fix-2026-10-28
- status: completed
- owner: project-manager
- source: GitHub Actions v0.2.2 and verified live DOMKAT update 28.10.2026.
- authority: verified-runtime
- verified outcome: signed-off installer CI, live update preserved existing Tunnel ID, one tunnel-client, Router Lite, DPAPI and local autostart; original connector ping, system tools and readyz successful.
- remaining work outside this commitment: physical client MKATUSHONOK connection tests.

## v0.2.3 Settings window, server status and icon
- commitment_id: server-settings-tray-icon-2026-10-28
- status: accepted/active
- owner: project-manager
- source: Owner reported false «Нет соединения», inert Settings menu and requested a new icon on 28.10.2026.
- authority: owner-directive
- verified partial progress: source now has modeless Settings, named-event --settings, independent Server readyz/router health and new native ICO with colored tray dot. Self-contained app build, --selftest, --test-icons, --probe-server all returned 0 on DOMKAT.
- remaining: Windows Inno CI acceptance, publish v0.2.3, deploy to DOMKAT and verify visible Settings window and correct tooltip.

## Native visibility supplement to GUI fix
- commitment_id: server-settings-native-visible-2026-10-28
- status: accepted/active
- owner: project-manager
- source: Owner reported inert Settings menu; v0.2.3 callback was reached but native window stayed hidden.
- authority: owner-directive
- verified partial progress: reproducing actual hidden native HWND and successful ShowWindow SW_SHOW on DOMKAT, v0.2.4 source patch and self-contained local selftests.
- remaining: Windows CI installer v0.2.4 and live DOMKAT update with visible-menu acceptance.

## v0.2.5 two installers; do not install on DOMKAT
- commitment_id: approved-settings-both-installers-2026-10-28
- status: accepted/active
- owner: project-manager
- source: owner approved HTML settings mockup then requested full and update installers, explicitly reserving right to use built-in updater personally.
- authority: owner-directive
- verified partial progress: source implements approved server/client secret-free main forms and temporary entry, automated --test-secret-forms plus selftest/icon/probe pass in local publish.
- remaining: validate capsule, commit, GitHub Windows installer CI, publish/verify binary Release. No DOMKAT update or change of 192.168.0.3.

## Installer artifact delivery completed
- commitment_id: approved-settings-both-installers-2026-10-28
- status: completed
- owner: project-manager
- source: GitHub Release v0.2.5 and successful Windows Actions 40732281198.
- authority: verified-repository
- verified outcome: full and update EXEs published with SHA256, release not draft or prerelease, install/update/uninstall checks passed. DOMKAT update deliberately not executed; owner will use built-in program updater.

## v0.2.6 updater fix deliverable
- commitment_id: repair-built-in-updater-ioexception-2026-10-28
- status: accepted/active
- source: owner supplied v0.2.5 updater failure screenshot; source and log identify unclosed staging stream.
- authority: owner-incident, verified-runtime
- completed: scoped file writer, verify complete length, protect existing install on failure; new Windows regression test, local tests.
- remaining: stable GitHub full/update binary v0.2.6 with Windows CI; leave DOMKAT installed software untouched.

## Repair-built-in-updater-ioexception-2026-10-28
- status: completed (source/build/release), pending owner manual deployment and physical client acceptance.
- verified: v0.2.6 stable Setup/Update plus alias and Actions run 40736310056 success.
- source: verified GitHub Release v0.2.6.
- authority: verified-repository, owner-directive.
